# Twilio integracija

- Sukurk Twilio paskyrą ir telefono numerį
- Nustatyk Voice webhook URL į `https://<tavaserveris>/twilio-webhook`
- Twilio gali naudoti TwiML <Play> su viešu audio URL arba <Say> kaip fallback
- Dėl real-time: naudok Twilio Media Streams arba WebRTC
