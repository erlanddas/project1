# Prompt'ai ir lietuvių kalbos geriausios praktikos

- Nurodyk: "Atsakyk lietuviškai" ir pageidaujamą toną
- Pritaikyk punktuaciją TTS (trumpi sakiniai, taškai)
- Patikrink diakritiką ir vietinius terminus
