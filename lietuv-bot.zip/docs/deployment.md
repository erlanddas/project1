# Deployment

Galimos parinktys:
- Railway / Render: lengva hostinti Node app
- Vercel: serverless funkcijos (reikia pritaikyti kodą)
- AWS (EC2 / Elastic Beanstalk) arba Docker + ECS

Užtikrink, kad tavo serveris būtų pasiekiamas per HTTPS jei naudoji Twilio.
