# TTS pasirinkimai

- ElevenLabs: aukštos kokybės balsai, kai kuriais atvejais turi lietuviškas galimybes
- Speechify: paprastesnė integracija
- Google Cloud TTS: platus balsų pasirinkimas ir SSML palaikymas
- VEED: vartotojo draugiškas

Rekomendacija: pradėti su ElevenLabs ir išbandyti kelis balsus.
