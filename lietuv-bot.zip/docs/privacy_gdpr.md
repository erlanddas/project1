# Privatumas / GDPR

- Informuok vartotojus apie duomenų rinkimą
- Saugok garso ir tekstinius duomenis, jei saugomi
- Jei reikia, anonimizuok duomenis
